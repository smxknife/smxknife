package com.smxknife.game.hero;

import com.google.protobuf.GeneratedMessageV3;
import com.smxknife.game.hero.protocol.GameMsgProtocol;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import lombok.extern.log4j.Log4j2;

/**
 * @author smxknife
 * 2021/5/6
 */
@Log4j2
public class GameMsgEncoder extends ChannelOutboundHandlerAdapter {
	@Override
	public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
		if (null == msg || !(msg instanceof GeneratedMessageV3)) {
			super.write(ctx, msg, promise);
			return;
		}

		int msgCode = -1;
		if (msg instanceof GameMsgProtocol.UserEntryResult) {
			msgCode = GameMsgProtocol.MsgCode.USER_ENTRY_RESULT_VALUE;
		} else if (msg instanceof GameMsgProtocol.WhoElseIsHereResult) {
			msgCode = GameMsgProtocol.MsgCode.WHO_ELSE_IS_HERE_RESULT_VALUE;
		} else if (msg instanceof GameMsgProtocol.UserMoveToResult) {
			msgCode = GameMsgProtocol.MsgCode.USER_MOVE_TO_RESULT_VALUE;
		} else if (msg instanceof GameMsgProtocol.UserQuitResult) {
			msgCode = GameMsgProtocol.MsgCode.USER_QUIT_RESULT_VALUE;
		} else {
			log.error("无法识别消息类型：msgClass：{}", msg.getClass().getName());
			return;
		}

		final GeneratedMessageV3 msgBody = (GeneratedMessageV3) msg;
		final ByteBuf buffer = ctx.alloc().buffer();
		buffer.writeShort((short)0);
		buffer.writeShort((short)msgCode);
		buffer.writeBytes(msgBody.toByteArray());

		BinaryWebSocketFrame frame = new BinaryWebSocketFrame(buffer);
		super.write(ctx, frame, promise);
	}
}
