package com.smxknife.game.hero;

import com.smxknife.game.hero.protocol.GameMsgProtocol;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.log4j.Log4j2;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * @author smxknife
 * 2021/5/5
 */
@Log4j2
public class GameMessageHandler extends SimpleChannelInboundHandler<Object> {

	/**
	 * 必须是static
	 */
	private static ChannelGroup channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

	private static Map<Integer, User> userMap = new ConcurrentHashMap<>();

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		// 每增加一个用户添加到group中，为了实现消息的群发
		channelGroup.add(ctx.channel());
	}

	@Override
	public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
		// 当客户端离线时触发的函数
		super.handlerRemoved(ctx);
		final Channel channel = ctx.channel();
		channelGroup.remove(channel);
		final Integer userId = channel.attr(AttributeKey.<Integer>valueOf("userId")).get();
		if (Objects.isNull(userId)) {
			return;
		}
		userMap.remove(userId);
		final GameMsgProtocol.UserQuitResult userQuitResult = GameMsgProtocol.UserQuitResult.newBuilder()
				.setQuitUserId(userId).build();
		channelGroup.writeAndFlush(userQuitResult);
	}

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, Object o) throws Exception {
		log.info("收到用户消息：{}", o);
		if (o instanceof GameMsgProtocol.UserEntryCmd) {
			final GameMsgProtocol.UserEntryCmd userEntryCmd = (GameMsgProtocol.UserEntryCmd) o;
			final int userId = userEntryCmd.getUserId();
			final String heroAvatar = userEntryCmd.getHeroAvatar();

			userMap.putIfAbsent(userId, new User(userId, heroAvatar));
			// 将userId附着到channel
			ctx.channel().attr(AttributeKey.valueOf("userId")).set(userId);

			final GameMsgProtocol.UserEntryResult userEntryResult = GameMsgProtocol.UserEntryResult.newBuilder()
					.setUserId(userId)
					.setHeroAvatar(heroAvatar)
					.build();
			channelGroup.writeAndFlush(userEntryResult);
		} else if (o instanceof GameMsgProtocol.WhoElseIsHereCmd) {
			final List<GameMsgProtocol.WhoElseIsHereResult.UserInfo> userInfos = userMap.values().stream()
					.filter(Objects::nonNull)
					.map(user -> GameMsgProtocol.WhoElseIsHereResult.UserInfo
							.newBuilder().setUserId(user.getUserId()).setHeroAvatar(user.getHeroAvatar()).build())
					.collect(Collectors.toList());
			final GameMsgProtocol.WhoElseIsHereResult whoElseIsHereResult = GameMsgProtocol.WhoElseIsHereResult
					.newBuilder().addAllUserInfo(userInfos).build();
			ctx.writeAndFlush(whoElseIsHereResult);
		} else if (o instanceof GameMsgProtocol.UserMoveToCmd) {
			final Integer userId = (Integer)ctx.channel().attr(AttributeKey.valueOf("userId")).get();
			if (Objects.isNull(userId)) {
				return;
			}

			final GameMsgProtocol.UserMoveToCmd userMoveToCmd = (GameMsgProtocol.UserMoveToCmd) o;

			GameMsgProtocol.UserMoveToResult userMoveToResult = GameMsgProtocol.UserMoveToResult.newBuilder()
					.setMoveUserId(userId).setMoveToPosX(userMoveToCmd.getMoveToPosX())
					.setMoveToPosY(userMoveToCmd.getMoveToPosY()).build();
			channelGroup.writeAndFlush(userMoveToResult);
		}
	}
}
