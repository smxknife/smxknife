package com.smxknife.game.hero;

import com.google.protobuf.GeneratedMessageV3;
import com.smxknife.game.hero.protocol.GameMsgProtocol;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import lombok.extern.log4j.Log4j2;

import static com.smxknife.game.hero.protocol.GameMsgProtocol.MsgCode;
import static com.smxknife.game.hero.protocol.GameMsgProtocol.UserEntryCmd;

/**
 * @author smxknife
 * 2021/5/6
 */
@Log4j2
public class GameMsgDecoder extends ChannelInboundHandlerAdapter {
	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
//		log.info("收到消息：{}", msg);
		if (!(msg instanceof BinaryWebSocketFrame)) {
			// ctx.fireChannelRead(msg);
			return;
		}

		final BinaryWebSocketFrame binaryWebSocketFrame = (BinaryWebSocketFrame) msg;
		final ByteBuf byteBuf = binaryWebSocketFrame.content();
		// byteBuf里面的数据格式 0, 0, 0, 0, 8, 1, 118...
		// 前2位代表消息长度
		// 3-4位代表消息编号
		byteBuf.readShort(); // 读取消息的长度
		final int msgCode = byteBuf.readShort(); // 读取消息编号

		// 拿到消息体
		byte[] msgBody = new byte[byteBuf.readableBytes()];
		byteBuf.readBytes(msgBody);

		GeneratedMessageV3 cmd = null;

		switch (msgCode) {
			case MsgCode.USER_ENTRY_CMD_VALUE:
				cmd = UserEntryCmd.parseFrom(msgBody);
				break;
			case MsgCode.WHO_ELSE_IS_HERE_CMD_VALUE:
				cmd = GameMsgProtocol.WhoElseIsHereCmd.parseFrom(msgBody);
				break;
			case MsgCode.USER_MOVE_TO_CMD_VALUE:
				cmd = GameMsgProtocol.UserMoveToCmd.parseFrom(msgBody);
				break;
		}

		if (null != cmd) {
			// 将最开始websocket传过来的消息解码封装为UserEntryCmd，向下传递
			ctx.fireChannelRead(cmd);
		}
	}
}
